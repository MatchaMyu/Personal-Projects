/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package productionplanner;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate; // import the LocalDate class
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author myste
 */
public class productionplannermain extends JFrame implements ActionListener{
    JButton btnAddPoints, btnSubtractPoints, btnQuit;
    JLabel lblDate, lblPoints, lblGoal;
    
    int ppgoal = 0;
    int productionpoints = 0;
    Integer pp = productionpoints;
    
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    LocalDate now = LocalDate.now();
    
    Map<String, Integer> categoryPoints = new HashMap<>();
    Map<String, Integer> categoryPPgoal = new HashMap<>();
    Map<String, JLabel> categoryLabels = new HashMap<>();
    Map<String, JButton> addButtons = new HashMap<>();
    Map<String, JButton> subtractButtons = new HashMap<>();
    
        public productionplannermain() {
        // Initialize components
        initComponents();

        // Set up the layout
        setUpLayout();

        // Set up the frame
        setUpFrame();
    }

    private void initComponents() {
        btnAddPoints = new JButton("Add Points");
        btnAddPoints.addActionListener(this);

        btnSubtractPoints = new JButton("Subtract Points");
        btnSubtractPoints.addActionListener(this);

        btnQuit = new JButton("Quit");
        btnQuit.addActionListener(this);

        lblDate = new JLabel(dtf.format(now));
        lblPoints = new JLabel(Integer.toString(productionpoints));
        lblGoal = new JLabel(Integer.toString(ppgoal));
        lblPoints.setHorizontalAlignment(JLabel.CENTER);
        lblPoints.setVerticalAlignment(JLabel.CENTER);
        lblGoal.setVerticalAlignment(JLabel.CENTER);
        lblGoal.setHorizontalAlignment(JLabel.CENTER);
        
        //Add more categories here
        categoryPoints.put("Japanese", 0);
        categoryPoints.put("Writing", 0);
        categoryPoints.put("Cleaning", 0);
        categoryPoints.put("Programming", 0);
        categoryPoints.put("Health", 0);
        
    // Create UI components for each category
    for (String category : categoryPoints.keySet()) {
        JLabel lblCategory = new JLabel("0");
        lblCategory.setHorizontalAlignment(JLabel.CENTER);
        lblCategory.setVerticalAlignment(JLabel.CENTER);
        categoryLabels.put(category, lblCategory);
        
        JButton btnAdd = new JButton("Add Points");
        btnAdd.setActionCommand("Add_" + category);
        btnAdd.addActionListener(this);
        addButtons.put(category, btnAdd);

        JButton btnSubtract = new JButton("Subtract Points");
        btnSubtract.setActionCommand("Subtract_" + category);
        btnSubtract.addActionListener(this);
        subtractButtons.put(category, btnSubtract);
        }
    }

    private void setUpLayout() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

    int rowIndex = 4;
    for (String category : categoryLabels.keySet()) {
        JLabel lblCategory = categoryLabels.get(category);
        JButton btnAdd = addButtons.get(category);
        JButton btnSubtract = subtractButtons.get(category);

        // Add category label
        gbc.gridx = 0;
        gbc.gridy = rowIndex;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        add(new JLabel(category), gbc);

        rowIndex++; // Increment rowIndex after adding the category label

        // Add points label (lblCategory)
        gbc.gridy = rowIndex;
        gbc.gridwidth = 1;
        add(lblCategory, gbc);

        rowIndex++; // Increment rowIndex after adding the points label

        // Add add-points button (btnAdd)
        gbc.gridy = rowIndex;
        add(btnAdd, gbc);

        // Add subtract-points button (btnSubtract)
        gbc.gridx = 1;
        add(btnSubtract, gbc);

        rowIndex++; // Increment rowIndex after adding the buttons
}
        
        // Add the quit button
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.WEST;
        add(btnQuit, gbc);

        // Add the date label
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.EAST;
        add(lblDate, gbc);
    }

    private void setUpFrame() {
        setTitle("Production Planner");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        Object source = event.getSource();
        if (source == btnAddPoints) {
            productionpoints += 10;
        }
        
        if (source == btnSubtractPoints) {
            productionpoints -= 10;
        }
        
        repaint();
        
    // Update points for each category
    for (String category : categoryPoints.keySet()) {
        if (source == addButtons.get(category) || source == subtractButtons.get(category)) {
            int pointsToAdd = source == addButtons.get(category) ? 10 : -10;
            int currentPoints = categoryPoints.get(category);
            int newPoints = currentPoints + pointsToAdd;
            categoryPoints.put(category, newPoints);

            JLabel lblCategory = categoryLabels.get(category);
            lblCategory.setText(Integer.toString(newPoints));
        }
    }
        
        if (source == btnQuit ){
        System.exit(0b0);  
        }
        
        System.out.println(pp); //Displays the points added/subtracted
        System.out.println(productionpoints); //Displays the points added/subtracted
    }
    
    
    private static void setLookAndFeel() {
        try {
            UIManager.setLookAndFeel(
            "javax.swing.plaf.nimbus.NimbusLookAndFeel");
        }
        catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException exc) {
            System.err.println(exc);
        }
    }
    
    public static void main(String[] arguments) {
        productionplannermain.setLookAndFeel();
        productionplannermain frame = new productionplannermain();
    }
    
}
